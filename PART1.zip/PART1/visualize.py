import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import datetime as dt
# common imports
import zipfile
import time
import time
# import datetime, timedelta
import datetime
from datetime import datetime, timedelta
from datetime import date
from dateutil import relativedelta
from io import StringIO
import pandas as pd
import pickle
from sklearn.base import BaseEstimator
from sklearn.base import TransformerMixin
from io import StringIO
import requests
import json
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import matplotlib  
import os
import math
from subprocess import check_output
import seaborn as sns
from IPython.display import display
import logging

import re
import os
dfs = pd.read_excel("LocationsAfter.xlsx")

print(dfs["lat_long"])

    
    
dfs['lat_long'] = dfs['lat_long'].to_numpy() 
dfs['latitude'] = dfs['latitude'].to_numpy()  
dfs['longitude'] = dfs['longitude'].to_numpy()  

 




dfs = dfs[~dfs.lat_long.str.contains("None")]
print(dfs.head())
df=dfs
df['latitude']= df['latitude'].astype(float)
df['longitude'] = df['longitude'].astype(float)



min_lat = 43.58735
max_lat = 43.687840
min_long = -79.547860
max_long = -79.280260    
    
    
df = df[df.latitude >= min_lat]
df = df[df.latitude <= max_lat]
df = df[df.longitude >= min_long]
df = df[df.longitude <= max_long]
print(df.head())


#df.to_excel("preprocess.xlsx") 

import folium
from folium.features import CustomIcon
from folium.plugins import MarkerCluster
from folium.utilities import write_png


TOR_COORDINATES = (df['latitude'].mean(), df['longitude'].mean())
 
# subset to match subset of locations
MAX_RECORDS = 2500
  
# create empty map zoomed in on Toronto
map_tor = folium.Map(location=TOR_COORDINATES, zoom_start=12)

mc = MarkerCluster()

# iterate through dataset to create clusters

for row in df[0:MAX_RECORDS].itertuples():
    mc.add_child(folium.Marker(location=[row.latitude,  row.longitude],
                 popup=row.lat_long))

map_tor.add_child(mc)
map_tor.save("filename.png")
map_tor.save('osm.html')
display(map_tor)
 
 


