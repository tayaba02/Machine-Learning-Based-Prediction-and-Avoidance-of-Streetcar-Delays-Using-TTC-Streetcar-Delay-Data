import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import datetime as dt
# common imports
import zipfile
import time
import time
# import datetime, timedelta
import datetime
from datetime import datetime, timedelta
from datetime import date
from dateutil import relativedelta
from io import StringIO
import pandas as pd
import pickle
from sklearn.base import BaseEstimator
from sklearn.base import TransformerMixin
from io import StringIO
import requests
import json
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import matplotlib  
import os
import math
from subprocess import check_output
import seaborn as sns
from IPython.display import display
import logging

import re
import os

import sys
import csv
import glob
import pandas as pd


df = pd.read_excel("LocationsBefore.xlsx")
l = df['Location']
    
data = []
datalat=[]
datalong = []
#######################################Converting location to latitude and longitude.
from geopy.geocoders import Nominatim
d={}
geolocator = Nominatim(user_agent="specify_your_app_name_here")
count=0
from geopy.exc import GeocoderTimedOut

def do_geocode(address, attempt=1, max_attempts=5):
    try:
        return geolocator.geocode(address)
    except GeocoderTimedOut:
        if attempt <= max_attempts:
            return do_geocode(address, attempt=attempt+1)
        raise


for x in range(5900,5901):
    www = l[x]
    location = do_geocode(www)
    print(count)
    count=count+1
    if location==None:
        print(location)
        data.append("None")
        datalat.append("None")
        datalong.append("None")

    else:
        print(location)
        data.append(location)
        datalat.append(location.latitude)
        datalong.append(location.longitude)

d['lat_long'] = data
d['latitude'] = datalat
d['longitude'] = datalong
print(datalat)
print(datalong)

d = pd.DataFrame(d) 

#d.to_excel("Finaldata6.xlsx")     
    
