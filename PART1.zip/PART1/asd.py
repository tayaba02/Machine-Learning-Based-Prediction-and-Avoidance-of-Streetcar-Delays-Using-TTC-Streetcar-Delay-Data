import zipfile
import pandas as pd
import numpy as np
import time
# import datetime, timedelta
import datetime
from datetime import datetime, timedelta
from datetime import date
from dateutil import relativedelta
from io import StringIO
import pandas as pd
import pickle
from sklearn.base import BaseEstimator
from sklearn.base import TransformerMixin
# DSX code to import uploaded documents
from io import StringIO
import requests
import json
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

import os
import math
from subprocess import check_output
import seaborn as sns
from IPython.display import display
#model libraries
from keras.layers import Input, Dropout, Dense, BatchNormalization, Activation, concatenate, GRU, Embedding, Flatten, BatchNormalization
from keras.models import Model
from keras.callbacks import ModelCheckpoint, Callback, EarlyStopping
from keras import regularizers
from keras.layers.normalization import BatchNormalization
from keras.regularizers import l2
from keras.optimizers import Adam
from keras.optimizers import SGD
from keras import backend as K
from keras.utils.vis_utils import plot_model
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import load_model
#import datetime
#from datetime import date
from sklearn import metrics

def get_time(hour):
    for tod in time_of_day:
        if (hour >= time_of_day[tod]['start']) and (hour < time_of_day[tod]['end']):
            tod_out = tod
    return(tod_out)

def weekend_time(day, tod):
    if (day=='Saturday') or (day=='Sunday'):
        return('w'+tod)
    else:
        return(tod)
 
def ingest_data(path):
    routedirection_frame = pd.read_excel("Route.xlsx") 
    routedirection_frame.tail()

    merged_data = pd.read_excel("preprocess.xlsx")
    love  = merged_data['Route'].values
    love2  = merged_data['Direction'].values
    
    R = {}
    for l in range(0,len(love)):
        R[str(love[l])+str(love2[l])]= 1
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    print(len(R))
    print(R)
    print(merged_data['Report Date'])
    print(merged_data['Report Date'].head())
    
    return(routedirection_frame, merged_data)    
    
def prep_merged_data(merged_data):

    merged_data['year'] = pd.DatetimeIndex(merged_data['Report Date']).year
    merged_data['month'] = pd.DatetimeIndex(merged_data['Report Date']).month
    merged_data['daym'] = pd.DatetimeIndex(merged_data['Report Date']).day
    merged_data['hour'] = pd.DatetimeIndex(merged_data['Report Date Time']).hour
    merged_data['time_of_day'] = merged_data['hour'].apply(lambda x:get_time(x))
    merged_data['time_of_day'] = merged_data.apply(lambda x: weekend_time(x['Day'], x['time_of_day']), axis=1)
    if targetcontinuous:
        merged_data['target'] = merged_data['Min Delay']
    else:
        merged_data['target'] = np.where(merged_data['Min Delay'] >= targetthresh, 1, 0 )
    return(merged_data)    

def prep_sparse_df(routedirection_frame, merged_data):
    routedirection_frame['count'] = 0
    print("routedirection")
    display(routedirection_frame[:5])
    print(routedirection_frame)
    print()
    days = pd.date_range(start_date, end_date, freq='D')
    date_frame = pd.DataFrame({'Report Date':days,'count':0})
    hour_list = list(range(0,24))
    hour_frame = pd.DataFrame({'hour':hour_list,'count':0})   
    result1 = pd.merge(date_frame, routedirection_frame, on='count', how='inner')
    print(result1)
    result2 = pd.merge(result1, hour_frame, on='count', how='outer')
    print(result2)   
    result2 = result2.rename(columns={'date': 'Report Date'})
    result2.Route = result2.Route.astype(str)
    result2['year'] = pd.DatetimeIndex(result2['Report Date']).year
    result2['month'] = pd.DatetimeIndex(result2['Report Date']).month
    result2['daym'] = pd.DatetimeIndex(result2['Report Date']).day
    result2['day'] = pd.DatetimeIndex(result2['Report Date']).weekday
    merged_data = merged_data.drop(['Time',
     'Report Date Time',
     'year',
     'month',
     'daym',
     'time_of_day','Min Gap','Location','Incident','Vehicle','target','Day'],axis=1)
 
    result2['Route']=result2['Route'].astype(int)
 
    
    result3 = pd.merge(result2,merged_data ,how='left', on=['Report Date','Route','Direction','hour'])
    result3['Min Delay'].fillna(value=0.0,inplace=True)
    result3['target'] = np.where(result3['Min Delay'] > 0.0, 1, 0 )
    print(result3)
    return(result3)    

testproportion = 0.2 
trainproportion = 0.8  
verboseout = True
 
hctextmax = 7000
maxwords = 6000

targetthresh = 1.0
targetcontinuous = False 

 
time_of_day = {'overnight':{'start':0,'end':5},'morning_rush':{'start':5,'end':10},
              'midday':{'start':10,'end':15},'aft_rush':{'start':15,'end':19},'evening':{'start':19,'end':24}}
 
              


emptythresh = 6000
zero_weight = 1.0
one_weight =40

learning_rate = 0.001
dropout_rate = 0.0003 
l2_lambda = 0.0003 
loss_func = "binary_crossentropy"
if targetcontinuous:
    output_activation = "linear"
else:
    output_activation = "hard_sigmoid"
    

date_today = datetime.now()
start_date =  date(2014, 1, 2)
end_date = date(2019, 2, 28)

import sys
import csv
import glob
import pandas as pd
filenames = glob.glob( "preprocess.xlsx")
print(filenames)

directions_df, merged_data = ingest_data(filenames[0])
print(len(directions_df))
print(len(merged_data))

merged_data = prep_merged_data(merged_data)
print(merged_data.head())
print(len(merged_data))

merged_data['year'].value_counts()
merged_data.groupby(['Route','Direction']).size().reset_index().rename(columns={0:'count'}).tail(50)

merged_data = prep_sparse_df(directions_df, merged_data)
print("shape of refactored dataset", merged_data.shape)
count_no_delay = merged_data[merged_data['target']==0].shape[0]
count_delay = merged_data[merged_data['target']==1].shape[0]
print("count of no delay ",count_no_delay)
print("count of delay ",count_delay)

one_weight = count_no_delay/count_delay
print("one_weight is ",one_weight)





train, test = train_test_split(merged_data, test_size = testproportion)




print("Through train test split. Test proportion:")
print(testproportion)

display(merged_data[:5])

allcols = list(merged_data)
print("all cols",allcols)

textcols = [] 
continuouscols = [] 
if targetcontinuous:
    excludefromcolist = ['count','Report Date', 'target','count_md','Min Delay']
    
else:
    excludefromcolist = ['count','Report Date', 'target','count_md', 'Min Delay']

nontextcols = list(set(allcols) - set(textcols))
collist = list(set(nontextcols) - set(excludefromcolist) - set(continuouscols))

# print column list lengths and contents:
print("allcols",len(allcols))
print("excludefromcolist",len(excludefromcolist))
print(excludefromcolist)
print("textcols",len(textcols))
print(textcols)
print("continuouscols",len(continuouscols))
print(continuouscols)
print("collist",len(collist))
print(collist)
print(train)



for col in continuouscols:
    print("col is",col)
    merged_data[col] = merged_data[col].astype(float)
    print("got through one")
    superset_data[col] = superset_data[col].astype(float)


def fill_missing(dataset):
    for col in collist:
        dataset[col].fillna(value="missing", inplace=True)
    for col in continuouscols:
        dataset[col].fillna(value=0.0,inplace=True)
    for col in textcols:
        dataset[col].fillna(value="missing", inplace=True)
    return (dataset)

lelist = {}

for col in collist:
    le = LabelEncoder()
    if verboseout:
        print("processing ",col)
    le.fit(np.hstack([merged_data[col]]))
    train[col] = le.transform(train[col])
    test[col] = le.transform(test[col])
    lelist[col] = le
    del le
    
    


resarray = {}

def get_integer_mapping(le):
    res = {}
    for cl in le.classes_:
        res.update({cl:le.transform([cl])[0]})

    return res










max_dict = {}
textmax = 50

for col in collist:
    max_dict[col] = np.max([train[col].max(), test[col].max()])+1

                             
if verboseout:
    print("max_dict",max_dict)




dtrain, dvalid = train_test_split(train, random_state=123, train_size=trainproportion)

print(dtrain.shape)
print(dvalid.shape)
if verboseout:
    train["target"].head()


def get_keras_vars(dataset):
    X = {}
    dictlist = []
    for col in collist:
        if verboseout:
            print("cat col is",col)
        X[col] = np.array(dataset[col])
        dictlist.append(np.array(dataset[col]))
       

        
    return X, dictlist

def get_keras_list_only(X_in):
    dictlist = []
    for key, value in X_in.items():
        print("X def loop key",key)
        print("value shape",value.shape)
        temp = [key,value]
        dictlist.append(value)
    return dictlist

def get_keras_np(X_in):
    return np.array(list(X_in.items()),dtype=object)
# np.array(list(result.items()), dtype=dtype)


 
import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files (x86)/Graphviz2.38/bin/'
from sklearn.tree import export_graphviz
 



from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn import tree
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation, Flatten
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
from keras.callbacks import ModelCheckpoint
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mlxtend.plotting import plot_decision_regions
from sklearn.decomposition import PCA
from keras.utils.vis_utils import plot_model
def cm_analysis(y_true, y_pred, filename, labels, ymap=None, figsize=(10,10)):
    if ymap is not None:
        y_pred = [ymap[yi] for yi in y_pred]
        y_true = [ymap[yi] for yi in y_true]
        labels = [ymap[yi] for yi in labels]
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    cm_sum = np.sum(cm, axis=1, keepdims=True)
    cm_perc = cm / cm_sum.astype(float) * 100
    annot = np.empty_like(cm).astype(str)
    nrows, ncols = cm.shape
    for i in range(nrows):
        for j in range(ncols):
            c = cm[i, j]
            p = cm_perc[i, j]
            if i == j:
                s = cm_sum[i]
                annot[i, j] = '%.1f%%\n%d/%d' % (p, c, s)
            elif c == 0:
                annot[i, j] = ''
            else:
                annot[i, j] = '%.1f%%\n%d' % (p, c)
    cm = pd.DataFrame(cm, index=labels, columns=labels)
    cm.index.name = 'Actual'
    cm.columns.name = 'Predicted'
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(cm, annot=annot, fmt='', ax=ax)
    plt.savefig(filename)

def savingmodel(model,X,Y,Xtest,Ytest,y_pred,name):
    cm_analysis(Ytest, y_pred, name+"Confusion", [0,1], ymap=None, figsize=(10,10))
    if name!="NeuralNetwork":
        logit_roc_auc = roc_auc_score(Ytest, y_pred)
    
        fpr, tpr, thresholds = roc_curve(Ytest, model.predict_proba(Xtest)[:,1])
        plt.figure()
        plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
        plt.plot([0, 1], [0, 1],'r--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver operating characteristic')
        plt.legend(loc="lower right")
        plt.savefig(name+"ROC")
  

        classification_report(Ytest, y_pred)
        pca = PCA(n_components = 2)
        X_train2 = pca.fit_transform(X)

        if name =="MultinomialNB":
            model.fit(abs(X_train2), Y)
            plot_decision_regions(abs(X_train2), Y, clf=model, legend=5)
            plt.savefig(name+"Boundary")
            #plt.show()
        else:
            model.fit(X_train2, Y)
            plot_decision_regions(X_train2, Y, clf=model, legend=5)
            plt.savefig(name+"Boundary")
    else:
        plot_model(model, to_file=name+'.png', show_shapes=True, show_layer_names=True)
        


from sklearn.preprocessing import StandardScaler
 


X = dtrain.drop(['Report Date','count','target','Min Delay'], axis=1).to_numpy()
Y = dtrain['target'].to_numpy()
Xtest=test.drop(['Report Date','count','target','Min Delay'], axis=1).to_numpy()
Ytest=test['target'].to_numpy()

import xgboost as xgb

xgb_model = xgb.XGBClassifier(objective="binary:logistic", random_state=42,scale_pos_weight=940)
xgb_model.fit(X, Y)

y_pred = xgb_model.predict(Xtest)

print(confusion_matrix(Ytest, y_pred))
savingmodel(xgb_model,X,Y,Xtest,Ytest,y_pred,"XBOOSTClassifier")






parameters = {'bootstrap': True,
              'min_samples_leaf': 3,
              'n_estimators': 50, 
              'min_samples_split': 10,
              'max_features': 'sqrt',
              'max_depth': 10,
              'class_weight':{0:1,1:40},
              'max_leaf_nodes': None}

RF_model = RandomForestClassifier(**parameters)
RF_model.fit(X,Y)
RF_predictions = RF_model.predict(Xtest)
score = accuracy_score(Ytest ,RF_predictions)
print(score)


estimator = RF_model.estimators_[1]

export_graphviz(estimator, out_file='tree.dot', 
                feature_names = dtrain.drop(['Report Date','count','target','Min Delay'], axis=1).columns,
                class_names = ['0','1'],
                rounded = True, proportion = False, 
                precision = 2, filled = True)
from subprocess import call
call(['dot', '-Tpng', 'tree.dot', '-o', 'Randomforesttree.png', '-Gdpi=600'])

savingmodel(RF_model,X,Y,Xtest,Ytest,RF_predictions,"Randomforest")
##############################################

from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

##############################################
model = MLPClassifier( activation='relu',solver='adam', alpha=0.0001, batch_size='auto',  learning_rate_init=0.001)

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)
savingmodel(model,X,Y,Xtest,Ytest,y_pred,"MLPClassifier")
##############################################
model = DecisionTreeClassifier(criterion='gini', splitter='best', max_depth=10, class_weight={0:1,1:40})

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)


export_graphviz(model, out_file='Decisiontree.dot', 
                feature_names = dtrain.drop(['Report Date','count','target','Min Delay'], axis=1).columns,
                class_names = ['0','1'],
                rounded = True, proportion = False, 
                precision = 2, filled = True)
from subprocess import call
call(['dot', '-Tpng', 'Decisiontree.dot', '-o', 'Decisiontree.png', '-Gdpi=600'])

savingmodel(model,X,Y,Xtest,Ytest,y_pred,"TREE")


##############################################
model = AdaBoostClassifier( base_estimator = model,n_estimators=30, algorithm='SAMME.R')

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)


savingmodel(model,X,Y,Xtest,Ytest,y_pred,"AdaBoostClassifier")

##############################################
model = QuadraticDiscriminantAnalysis()

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)
savingmodel(model,X,Y,Xtest,Ytest,y_pred,"QuadraticDiscriminantAnalysis")
'''
##############################################
'''
model = GaussianProcessClassifier()

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)
savingmodel(model,X,Y,Xtest,Ytest,y_pred,"GaussianProcessClassifier")

'''
##############################################



'''
from sklearn.linear_model import SGDClassifier
model = SGDClassifier(loss="log", penalty="l2", class_weight={0:1,1:40})

print(model.fit(X,Y))
print(model.score(Xtest, Ytest))
y_pred = model.predict(Xtest)
savingmodel(model,X,Y,Xtest,Ytest,y_pred,"SGDClassifier")



#n_iters = [5, 10, 20, 50, 100, 1000]
#scores = []
#for n_iter in n_iters:
#    model = SGDClassifier(loss="hinge", penalty="l2", max_iter=n_iter, class_weight={0:1,1:400})
#    model.fit(X_train,Y)
#    scores.append(model.score(X_test, Ytest))
  
#plt.title("Effect of n_iter")
#plt.xlabel("n_iter")
#plt.ylabel("score")
#plt.plot(n_iters, scores) 

#losses = ["hinge", "log", "modified_huber", "perceptron", "squared_hinge"]
#scores = []
#for loss in losses:
#    model = SGDClassifier(loss=loss, penalty="l2", max_iter=1000, class_weight={0:1,1:400})
#    model.fit(X_train,Y)
#    scores.append(model.score(X_test, Ytest))
#  
#plt.title("Effect of loss")
#plt.xlabel("loss")
#plt.ylabel("score")
#x = np.arange(len(losses))
#plt.xticks(x, losses)
#plt.plot(x, scores)

#from sklearn.model_selection import GridSearchCV

#params = {
#    "loss" : ["hinge", "log", "squared_hinge", "modified_huber"],
#    "alpha" : [0.0001, 0.001, 0.01, 0.1],
#    "penalty" : ["l2", "l1", "none"],
#}

#model = SGDClassifier(max_iter=1000, class_weight={0:1,1:400})
#clf = GridSearchCV(model, param_grid=params)

#clf.fit(X_train, Y)
#print(clf.best_score_)

#print(clf.best_estimator_)


##############################################
from sklearn.naive_bayes import MultinomialNB

clf = MultinomialNB()

clf.fit(X, Y)
y_pred = clf.predict(Xtest)
print((clf.score(Xtest, Ytest)))
savingmodel(clf,X,Y,Xtest,Ytest,y_pred,"MultinomialNB")




##############################################

from sklearn.linear_model import LogisticRegression
from sklearn import metrics

logreg = LogisticRegression(penalty='l2', dual=False, tol=0.001, C=0.7, fit_intercept=True, intercept_scaling=1, class_weight={0:1,1:40}, random_state=None, solver='lbfgs', max_iter=100, multi_class='auto', verbose=0, warm_start=False, n_jobs=None, l1_ratio=None)
logreg.fit(X, Y)
y_pred = logreg.predict(Xtest)
savingmodel(logreg,X,Y,Xtest,Ytest,y_pred,"LogisticRegression")




##############################################
#from sklearn import svm
#clf = svm.SVC(kernel='linear') # Linear Kernel
#clf.fit(X, Y)
#y_pred = clf.predict(Xtest)
#from sklearn import metrics
#print("Accuracy:",metrics.accuracy_score(Ytest, y_pred))



import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC,  LinearSVC

from sklearn.preprocessing import MinMaxScaler
scaling = MinMaxScaler(feature_range=(-1,1)).fit(X)
X_train = scaling.transform(X)
X_test = scaling.transform(Xtest)

from sklearn.metrics import confusion_matrix
h = .02   

C = 1.0   
svc = SVC(kernel='linear', C=C,cache_size=10000).fit(X_train,Y)

y_pred = svc.predict(X_test)

cm = confusion_matrix(Ytest, y_pred )
print(cm)


print("Accuracy:",metrics.accuracy_score(Ytest, y_pred))



rbf_svc = SVC(kernel='rbf', gamma=0.7, C=C).fit(X, Y)

y_pred = rbf_svc.predict(Xtest)

print("Accuracy:",metrics.accuracy_score(Ytest, y_pred))
cm = confusion_matrix(Ytest, y_pred )
print(cm)


poly_svc = SVC(kernel='poly', degree=3, C=C).fit(X, Y)

y_pred = poly_svc.predict(Xtest)

print("Accuracy:",metrics.accuracy_score(Ytest, y_pred))
cm = confusion_matrix(Ytest, y_pred )
print(cm)




from sklearn.preprocessing import StandardScaler


from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=2)
knn.fit(X,Y)
y_pred = knn.predict(Xtest)
savingmodel(knn,X,Y,Xtest,Ytest,y_pred,"KNN")



import numpy as np
import pylab as pl
from sklearn import neighbors, datasets
from pandas.plotting import scatter_matrix
from matplotlib import cm

#cmap = cm.get_cmap('gnuplot')
#scatter = scatter_matrix(X, c = Y, marker = 'o', s=40, hist_kwds={'bins':15}, figsize=(9,9), cmap = cmap)
#plt.suptitle('Scatter-matrix for each input variable')
#plt.savefig('fruits_scatter_matrix')




#model.fit(X, Y)
# Extract single tree
#RF_predictions = model.predict(test.drop(['Report Date','count','target','Min Delay'], axis=1))
#score = accuracy_score(test['target'] ,RF_predictions)
#print(score)


#estimator = model.estimators_[1]

#export_graphviz(estimator, out_file='tree.dot', 
#                feature_names = dtrain.drop(['Report Date','count','target','Min Delay'], axis=1).columns,
#                class_names = ['0','1'],
#                rounded = True, proportion = False, 
#                precision = 0, filled = True)
#from subprocess import call
#call(['dot', '-Tpng', 'tree.dot', '-o', 'tree.png', '-Gdpi=600'])






#from IPython.display import Image
#Image(filename = 'tree.png')










#t = DecisionTreeClassifier()
#t.fit(dtrain.drop(['Report Date','count','target'], axis=1), dtrain['target'])
#print(t.score(test.drop(['Report Date','count','target'], axis=1), test['target']))

#plot_tree(RF_model, filled=True)
#plt.show()
 
X_train, X_train_list = get_keras_vars(dtrain)
X_valid, X_valid_list = get_keras_vars(dvalid)
X_test,X_test_list = get_keras_vars(test)
print("keras variables defined")
print("X_train_list",X_train_list)

print(X_train)
print(X_train_list)
print(X_valid)
print(X_valid_list)
print(X_test)
print(X_test_list)





def get_model():
    catinputs = {} 
    embeddings = {}
    catemb = 10 
    collistfix = []
    inputlayerlist = []
    for col in collist:
        catinputs[col] = Input(shape=[1],name=col)
        inputlayerlist.append(catinputs[col])
        embeddings[col] = (Embedding(max_dict[col],catemb) (catinputs[col]))
        print(embeddings[col])
        embeddings[col] = (BatchNormalization() (embeddings[col]))
        collistfix.append(embeddings[col])
    main_l = concatenate([Dropout(dropout_rate) (Flatten() (embeddings[collist[0]]) ),Dropout(dropout_rate) (Flatten() (embeddings[collist[1]]) )])
    print(main_l)
    for cols in collist:
        if (cols != collist[0]) & (cols != collist[1]):
            main_l = concatenate([main_l,Dropout(dropout_rate) (Flatten() (embeddings[cols]) )])
    print("main_l", main_l)                                            
    output = Dense(1, activation=output_activation) (main_l)                  
    model = Model(inputlayerlist, output)
    optimizer = SGD(lr=learning_rate)
    model.compile(loss=loss_func, optimizer=optimizer, metrics=["accuracy"], weighted_metrics=["accuracy"])
    return model

    
model = get_model()

 

#model.summary()
#from keras.utils import plot_model
#plot_model(model, to_file='model.png')

 

BATCH_SIZE = 1000
epochs = 50
print("text cols",textcols)
print("dropout ",dropout_rate)
print("L2 lambda ",l2_lambda)
print("batch size ",BATCH_SIZE)
print("epochs",epochs)
print("learning_rate",learning_rate)
print("loss function",loss_func)
print("output activation function",output_activation)


model = get_model()


modelfit = model.fit(X_train_list, dtrain.target, epochs=epochs, batch_size=BATCH_SIZE
         , validation_data=(X_valid_list, dvalid.target), class_weight = {0 : 1, 1: 20}, verbose=1)



preds = model.predict(X_test_list, batch_size=BATCH_SIZE)

print(preds)
savingmodel(model,X_train_list,dtrain.target,Xtest,Ytest,preds.round(),"NeuralNetwork")

scores = model.evaluate(X_test_list, test.target)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))







































































































































































































































